const buttonReset = document.getElementById('extensionReset');

const saveSheet = document.getElementById('saveSheetID');
const sheetInput = document.getElementById('googleSheetInput');

const saveAuditSheet = document.getElementById('saveAuditSheetID');
const sheetAuditInput = document.getElementById('auditSheetInput');

const saveScheduleSheet = document.getElementById('saveScheduleSheetID');
const sheetScheduleInput = document.getElementById('scheduleSheetInput');

const saveAccountIDs = document.getElementById('saveTestIDs');
const accountTeacherID = document.getElementById('testTeacherID');
const accountStudentID = document.getElementById('testStudentID');

function InitSettingsHandler()
{
    saveSheet.addEventListener('click', function(){
        localStorage.setItem('sheetID', sheetInput.value);
        
        alert('saved!')
    });
    saveAuditSheet.addEventListener('click', function(){
        localStorage.setItem('auditSheetID', sheetAuditInput.value);
        
        alert('saved!')
    });
    saveScheduleSheet.addEventListener('click', function(){
        localStorage.setItem('scheduleSheetLink', sheetScheduleInput.value);
        
        alert('saved!')
    });

    saveAccountIDs.addEventListener('click', function(){
        localStorage.setItem('testTeacherID', accountTeacherID.value);
        localStorage.setItem('testStudentID', accountStudentID.value);

        alert('saved!')
    });
    
    buttonReset.addEventListener('click', function(){
        localStorage.removeItem('sheetID');
        localStorage.removeItem('auditSheetID');
        localStorage.removeItem('scheduleSheetLink');
        localStorage.removeItem('testTeacherID');
        localStorage.removeItem('testStudentID');

        DisplayCurrentSelection();

        alert('reset completed.');
    });
}

function DisplayCurrentSelection()
{
    sheetInput.value = localStorage.getItem('sheetID');
    sheetAuditInput.value = localStorage.getItem('auditSheetID');
    sheetScheduleInput.value = localStorage.getItem('scheduleSheetLink');

    accountTeacherID.value = localStorage.getItem('testTeacherID');
    accountStudentID.value = localStorage.getItem('testStudentID');
}



    // Executing
InitSettingsHandler();
DisplayCurrentSelection();