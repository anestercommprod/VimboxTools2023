if(localStorage.getItem('sheetID') == null)
{
    localStorage.setItem('sheetID', '1vSY4mgMXcwP05RmnTd9uUpSyOyrxjZ_bYmHb3zsDVwg');
}
if(localStorage.getItem('auditSheetID') == null)
{
    localStorage.setItem('auditSheetID', '1mf9pFgyHu6M4LYvEaDt8xUDx0Ie2N1IbZZ7f54hFnJQ');
}
if(localStorage.getItem('scheduleSheetLink') == null)
{
    localStorage.setItem('auditSheetID', 'https://docs.google.com/spreadsheets/d/1_O5ootR0BhcuK6f3KKBUofcG6Kzllnt-WPjv8xA-Vn4/edit#gid=0');
}